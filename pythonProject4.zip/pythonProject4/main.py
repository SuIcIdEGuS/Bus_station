import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QPushButton, QDialog, QFormLayout, QLineEdit, QDialogButtonBox, QMessageBox, QListWidget, QListWidgetItem
import sqlite3

class EditDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Edit Dialog")
        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)

        layout = QVBoxLayout()

        self.form_layout = QFormLayout()
        layout.addLayout(self.form_layout)

        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

        self.setLayout(layout)

    def add_field(self, label, value=''):
        line_edit = QLineEdit()
        line_edit.setText(str(value))  # Convert value to string
        self.form_layout.addRow(label, line_edit)

    def set_field_values(self, values):
        for label, value in values.items():
            self.add_field(label, value)

    def get_field_values(self):
        field_values = {}
        for i in range(self.form_layout.rowCount()):
            label_item = self.form_layout.itemAt(i, QFormLayout.LabelRole)
            field_item = self.form_layout.itemAt(i, QFormLayout.FieldRole)
            if label_item and field_item:
                label = label_item.widget().text()
                value = field_item.widget().text()
                field_values[label] = value
        return field_values


class BusParkApp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Автобусный парк')
        self.setGeometry(100, 100, 400, 300)

        layout = QVBoxLayout()

        self.trips_button = QPushButton('Показать поездки')
        self.trips_button.clicked.connect(self.show_trips)
        layout.addWidget(self.trips_button)

        self.trips_list = QListWidget()
        layout.addWidget(self.trips_list)

        self.info_label = QLabel('Информация о марках автобусов:')
        layout.addWidget(self.info_label)

        self.brand_button = QPushButton('Показать марки автобусов')
        self.brand_button.clicked.connect(self.show_brands)
        layout.addWidget(self.brand_button)

        self.brand_list = QListWidget()
        layout.addWidget(self.brand_list)

        self.revenue_label = QLabel('Суммарная выручка для каждой даты:')
        layout.addWidget(self.revenue_label)

        self.revenue_button = QPushButton('Показать выручку по датам')
        self.revenue_button.clicked.connect(self.show_revenue)
        layout.addWidget(self.revenue_button)

        self.top_drivers_label = QLabel('Топ-3 водителей по заработку:')
        layout.addWidget(self.top_drivers_label)

        self.top_drivers_button = QPushButton('Показать топ-3 водителей')
        self.top_drivers_button.clicked.connect(self.show_top_drivers)
        layout.addWidget(self.top_drivers_button)

        self.edit_brand_button = QPushButton('Редактировать марки автобусов')
        self.edit_brand_button.clicked.connect(self.edit_brands)
        layout.addWidget(self.edit_brand_button)

        self.edit_bus_button = QPushButton('Редактировать номера автобусов')
        self.edit_bus_button.clicked.connect(self.edit_buses)
        layout.addWidget(self.edit_bus_button)  # Changed button name here

        self.edit_trip_button = QPushButton('Редактировать поездки')
        self.edit_trip_button.clicked.connect(self.edit_trips)
        layout.addWidget(self.edit_trip_button)

        self.setLayout(layout)

    def show_trips(self):
        conn = sqlite3.connect('bus_park.db')
        cursor = conn.cursor()
        cursor.execute('''SELECT DISTINCT id, route_number, direction, cost FROM Trips''')
        trips = cursor.fetchall()
        conn.close()

        self.trips_list.clear()
        for trip in trips:
            item = QListWidgetItem(f'Номер: {trip[0]}, Направление: {trip[2]}, Стоимость: {trip[3]}')
            self.trips_list.addItem(item)

    def show_brands(self):
        conn = sqlite3.connect('bus_park.db')
        cursor = conn.cursor()
        cursor.execute('''SELECT DISTINCT number, brand, release_date FROM Buses''')
        buses = cursor.fetchall()
        conn.close()

        self.brand_list.clear()
        for bus in buses:
            item = QListWidgetItem(f'Номер: {bus[0]}, Марка: {bus[1]}, Дата выпуска: {bus[2]}')
            self.brand_list.addItem(item)

    def show_revenue(self):
        conn = sqlite3.connect('bus_park.db')
        cursor = conn.cursor()
        cursor.execute('''SELECT trip_date, SUM(cost) FROM Trips GROUP BY trip_date''')
        revenue_by_date = cursor.fetchall()
        conn.close()

        revenue_info = '\n'.join([f'{revenue[0]} - {revenue[1]}' for revenue in revenue_by_date])
        self.revenue_label.setText(f'Суммарная выручка для каждой даты:\n{revenue_info}')

    def show_top_drivers(self):
        conn = sqlite3.connect('bus_park.db')
        cursor = conn.cursor()
        cursor.execute(
            '''SELECT driver_name, SUM(cost) AS total_revenue FROM Trips GROUP BY driver_name ORDER BY total_revenue DESC LIMIT 3''')
        top_drivers = cursor.fetchall()
        conn.close()

        top_drivers_info = '\n'.join([f'{driver[0]} - {driver[1]}' for driver in top_drivers])
        self.top_drivers_label.setText(f'Топ-3 водителей по заработку:\n{top_drivers_info}')

    def edit_brands(self):
        dialog = EditDialog(self)
        dialog.setWindowTitle('Редактирование марок автобусов')
        dialog.add_field('Марка 1:')
        dialog.add_field('Марка 2:')
        dialog.add_field('Марка 3:')
        if dialog.exec_():
            field_values = dialog.get_field_values()
            try:
                conn = sqlite3.connect('bus_park.db')
                cursor = conn.cursor()
                for i in range(1, 4):
                    cursor.execute('''UPDATE Buses SET brand = ? WHERE id = ?''', (field_values[f'Марка {i}'], i))
                conn.commit()
                conn.close()
                self.show_brands()
            except sqlite3.Error as e:
                QMessageBox.critical(self, "Error", f"Database error: {str(e)}")

    def edit_buses(self):
        dialog = EditDialog(self)
        dialog.setWindowTitle('Редактирование автобусов')
        dialog.add_field('Номер автобуса 1')
        dialog.add_field('Номер автобуса 2')
        dialog.add_field('Номер автобуса 3')
        if dialog.exec_():
            field_values = dialog.get_field_values()
            try:
                conn = sqlite3.connect('bus_park.db')
                cursor = conn.cursor()
                for i in range(1, 4):
                    cursor.execute('''UPDATE Buses SET number = ? WHERE id = ?''',
                                   (field_values[f'Номер автобуса {i}'], i))
                conn.commit()
                conn.close()
                self.show_brands()
            except sqlite3.Error as e:
                QMessageBox.critical(self, "Error", f"Database error: {str(e)}")

    def edit_trips(self):
        dialog = EditDialog(self)
        dialog.setWindowTitle('Редактирование поездок')

        conn = sqlite3.connect('bus_park.db')
        cursor = conn.cursor()
        cursor.execute('''SELECT id, trip_date, driver_name, route_number, direction, cost FROM Trips''')
        trips_data = cursor.fetchall()
        conn.close()

        existing_data = {}
        for index, trip in enumerate(trips_data):
            trip_info = {
                'Дата поездки': trip[1],
                'Имя водителя': trip[2],
                'Номер маршрута': str(trip[3]),
                'Направление': trip[4],
                'Стоимость': str(trip[5])
            }
            existing_data[f'Поездка {index + 1}'] = trip_info

        dialog.set_field_values(existing_data)
        num_existing_trips = len(trips_data)
        if num_existing_trips < 3:
            for i in range(num_existing_trips + 1, 4):
                dialog.add_field(f'Поездка {i}: Дата поездки')
                dialog.add_field(f'Поездка {i}: Имя водителя')
                dialog.add_field(f'Поездка {i}: Номер маршрута')
                dialog.add_field(f'Поездка {i}: Направление')
                dialog.add_field(f'Поездка {i}: Стоимость')

        if dialog.exec_():
            field_values = dialog.get_field_values()
            try:
                conn = sqlite3.connect('bus_park.db')
                cursor = conn.cursor()
                for i, trip in enumerate(trips_data):
                    update_values = (
                        field_values[f'Поездка {i + 1}']['Дата поездки'],
                        field_values[f'Поездка {i + 1}']['Имя водителя'],
                        int(field_values[f'Поездка {i + 1}']['Номер маршрута']),
                        field_values[f'Поездка {i + 1}']['Направление'],
                        float(field_values[f'Поездка {i + 1}']['Стоимость']),
                        trip[0]
                    )
                    cursor.execute('''UPDATE Trips SET trip_date = ?, driver_name = ?, route_number = ?, 
                                      direction = ?, cost = ? WHERE id = ?''', update_values)
                conn.commit()
                conn.close()
                self.show_trips()
            except sqlite3.Error as e:
                QMessageBox.critical(self, "Error", f"Database error: {str(e)}")


if __name__ == '__main__':
    conn = sqlite3.connect('bus_park.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS Buses (
                        id INTEGER PRIMARY KEY,
                        number INTEGER,
                        brand TEXT,
                        release_date DATE)''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS Trips (
                        id INTEGER PRIMARY KEY,
                        bus_id INTEGER,
                        trip_date DATE,
                        driver_name TEXT,
                        route_number INTEGER,
                        direction TEXT,
                        cost DECIMAL(10, 2))''')

    conn.commit()
    conn.close()

    app = QApplication(sys.argv)
    window = BusParkApp()
    window.show()
    sys.exit(app.exec_())
